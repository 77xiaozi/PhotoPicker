//
//  CollectionViewCell.h
//  SJPhotoPickerDemo
//
//  Created by Jaesun on 16/8/24.
//  Copyright © 2016年 S.J. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CollectionViewCell : UICollectionViewCell

@property (strong, nonatomic) IBOutlet UIImageView *imgView;

@end
